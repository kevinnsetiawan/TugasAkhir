import json
import random
import requests


class HTTPClient:
    def __init__(self, base_url: str, endpoints: list[dict] = None, timeout: int = 10):
        self.base_url = base_url.rstrip("/")
        self.endpoints = endpoints or [{"path": "/", "param": "q", "method": "GET"}]
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "RL-Pentest-Agent/1.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        })

    def surface_of(self, endpoint_index: int) -> str:
        """Permukaan serang yang dideklarasikan untuk endpoint (sql/file/plain)."""
        if endpoint_index is None or endpoint_index >= len(self.endpoints):
            return "plain"
        return self.endpoints[endpoint_index].get("surface", "plain")

    def send_payload(self, payload: str, endpoint_index: int = None):
        target = self.endpoints[endpoint_index] if endpoint_index is not None else random.choice(self.endpoints)
        method = target.get("method", "GET")
        try:
            if method == "POST":
                return self._send_post(payload, target)
            if method == "PUT":
                return self._send_json(payload, target, method="PUT")
            return self._send_get(payload, target)
        except requests.RequestException as error:
            raise RuntimeError(str(error)) from error

    def _send_get(self, payload: str, target: dict):
        url = f"{self.base_url}{target['path']}"
        if target["param"] == "path":
            url = url + payload
            return self.session.get(url, timeout=self.timeout, allow_redirects=True)
        return self.session.get(
            url,
            params={target["param"]: payload},
            timeout=self.timeout,
            allow_redirects=True,
        )

    def _send_post(self, payload: str, target: dict):
        return self._send_json(payload, target, method="POST")

    def _send_json(self, payload: str, target: dict, method: str = "POST"):
        url = f"{self.base_url}{target['path']}"
        headers = {"Content-Type": "application/json"}
        try:
            body = json.loads(payload)
        except json.JSONDecodeError:
            body = {"data": payload}
        if not isinstance(body, dict):
            body = {"data": body}
        for key, value in (target.get("defaults") or {}).items():
            body.setdefault(key, value)
        if target.get("captcha"):
            body = self._with_captcha(body)
        return self.session.request(
            method, url, json=body, headers=headers, timeout=self.timeout, allow_redirects=True
        )

    def _with_captcha(self, body: dict) -> dict:
        """Juice Shop v20 mewajibkan CAPTCHA pada submission feedback
        (routes/captcha.ts:37-45). Tanpa captchaId, Sequelize melempar
        "WHERE parameter captchaId has invalid undefined value" dan endpoint
        selalu membalas 500. Jawaban diambil apa adanya dari /rest/captcha."""
        try:
            captcha = self.session.get(
                f"{self.base_url}/rest/captcha", timeout=self.timeout
            ).json()
        except (requests.RequestException, ValueError) as error:
            raise RuntimeError(str(error)) from error
        enriched = dict(body)
        enriched["captchaId"] = captcha.get("captchaId")
        enriched["captcha"] = captcha.get("answer")
        return enriched