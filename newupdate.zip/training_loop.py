import re
import time
from datetime import datetime, timezone

CONTROL_BENIGN = "hello"


def neutralize_payload(payload: str, vuln_class: str) -> str:
    """Varian kontrol yang mempertahankan bentuk payload namun me-nonaktifkan
    vektor serangannya. Digunakan sebagai pembanding dalam verifikasi false
    positive: jika kontrol ini memicu kelas kerentanan yang SAMA, berarti
    respons bukan efek payload melainkan perilaku generik endpoint."""
    if vuln_class == "sqli":
        control = payload.replace("'", "")
        control = control.replace("--", "")
        control = control.replace(";", "")
        control = control.replace("SLEEP(5)", "SLEEP(0)")
        return control
    if vuln_class == "xss":
        from analyzer.response_analyzer import XSS_PAYLOAD_SIGNATURES
        control = payload
        for kw in XSS_PAYLOAD_SIGNATURES:
            control = control.replace(kw, "")
        return control
    if vuln_class == "fuzzing":
        return re.sub(r"['\"<>%\\/\x00]", "", payload) or CONTROL_BENIGN
    return CONTROL_BENIGN


def verify_vulnerability(client, analyzer, payload_text, endpoint_index, vuln_class):
    """Verifikasi false positive berbasis kontrol-diferensial. Suatu temuan
    diterima sebagai kerentanan hanya jika TIDAK SATU PUN probe kontrol
    (benign 'hello' maupun varian payload yang dinetralkan) memicu kelas
    kerentanan yang sama. Kegagalan koneksi dianggap tidak konklusif.

    Mengembalikan (terverifikasi, jumlah_request_kontrol) sehingga hitungan
    request verifikasi mencerminkan probe yang benar-benar dikirim.

    Mutan yang tidak berubah dari payload asli (mis. wildcard SQL '%s%s%s'
    yang tidak memuat kutip untuk dibuang) TIDAK dipakai sebagai kontrol,
    sebab ia bukan probing independen dan akan selalu mereproduksi kelas yang
    sama sehingga menolak setiap temuan tanpa alasan."""
    surface = client.surface_of(endpoint_index)
    controls = [(CONTROL_BENIGN, CONTROL_BENIGN)]
    mutant = neutralize_payload(payload_text, vuln_class)
    if mutant and mutant != payload_text:
        controls.append(("mutant", mutant))
    for _tag, text in controls:
        try:
            resp = client.send_payload(text, endpoint_index=endpoint_index)
            control_analysis = analyzer.analyze(
                resp, text, endpoint_index=endpoint_index, surface=surface
            )
        except RuntimeError:
            return False, len(controls)
        if control_analysis.get("vulnerability") == vuln_class:
            return False, len(controls)
    return True, len(controls)


def verify_xss_in_browser(browser_verifier, page_path, payload_text, vuln_class="xss"):
    """Bukti eksekusi XSS: vektor harus benar-benar dieksekusi DOM pada
    halaman frontend, sedangkan varian yang dinetralkan tidak boleh eksekusi.
    Navigasi browser dihitung sebagai request verifikasi oleh pemanggil."""
    if browser_verifier is None or not page_path:
        return False
    if not browser_verifier.verify(page_path, payload_text):
        return False
    control = neutralize_payload(payload_text, vuln_class)
    if not control or control == payload_text:
        return True
    return not browser_verifier.verify(page_path, control)


def probe_endpoint_baselines(client, analyzer):
    baselines = {}
    for endpoint_index in range(len(client.endpoints)):
        try:
            resp = client.send_payload("hello", endpoint_index=endpoint_index)
            baselines[endpoint_index] = len((resp.text or "").lower())
        except RuntimeError:
            continue
    if baselines:
        analyzer.set_baselines(baselines)
    return baselines


def run_episode(agent, payload_generator, client, analyzer, reward_system, current_state,
                mask=None, browser_verifier=None, xss_pages=None):
    if mask is None:
        action = agent.choose_action(current_state)
    else:
        action = agent.choose_action(current_state, mask=mask)
    payload_entry, endpoint_index = payload_generator.get_payload_and_endpoint(action)
    payload_text = payload_entry["payload"]
    payload_name = payload_entry["name"]
    payload_category = payload_entry.get("category", "")

    start_request = time.time()
    try:
        response = client.send_payload(payload_text, endpoint_index=endpoint_index)
        response_time = time.time() - start_request
        analysis = analyzer.analyze(
            response, payload_text, response_time=response_time, endpoint_index=endpoint_index,
            surface=client.surface_of(endpoint_index),
        )
    except RuntimeError:
        response_time = time.time() - start_request
        analysis = {
            "status_code": 0,
            "status_category": "error",
            "response_length": 0,
            "length_category": 0,
            "response_time_category": 0,
            "content_type_category": 0,
            "error_flag": False,
            "reflected_flag": False,
            "significant_change": False,
            "vulnerability": "none",
            "has_csp": False,
            "request_error": True,
        }

    verification_requests = 0
    is_verified = False
    browser_checked = False
    rejected_class = "none"
    xss_page = (xss_pages or {}).get(endpoint_index)

    if payload_category == "xss" and xss_page:
        # Konfirmasi XSS hanya sah bila vektor dieksekusi DOM sungguhan; RESPONS
        # HTTP bukan bukti karena vektor bisa tersimpan di JSON yang inaktif.
        before = browser_verifier.navigations if browser_verifier else 0
        executed = verify_xss_in_browser(browser_verifier, xss_page, payload_text)
        if browser_verifier:
            verification_requests += browser_verifier.navigations - before
        browser_checked = True
        analysis["xss_browser_checked"] = True
        analysis["vulnerability"] = "xss" if executed else "none"
        is_verified = executed
    else:
        vuln_class = analysis.get("vulnerability")
        if vuln_class != "none":
            is_verified, verification_requests = verify_vulnerability(
                client, analyzer, payload_text, endpoint_index, vuln_class
            )
            if not is_verified:
                rejected_class = vuln_class
                analysis["vulnerability"] = "none"

    reward = reward_system.compute_reward(analysis, verified=is_verified)
    next_state = (
        analysis["status_category"],
        analysis.get("length_category", 1),
        int(analysis["error_flag"]),
        int(analysis["reflected_flag"]),
        int(analysis.get("vulnerability", "none") != "none"),
        endpoint_index,
        analysis.get("response_time_category", 0),
        analysis.get("content_type_category", 0),
    )
    agent.learn(current_state, action, reward, next_state)

    record = {
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "action_index": action,
        "action_name": f"{payload_name}@ep{endpoint_index}",
        "payload": payload_text,
        "endpoint_index": endpoint_index,
        "status_code": analysis["status_code"],
        "response_length": analysis["response_length"],
        "response_time": round(response_time, 4),
        "status_category": analysis["status_category"],
        "response_time_category": analysis.get("response_time_category", 0),
        "content_type_category": analysis.get("content_type_category", 0),
        "error_flag": analysis["error_flag"],
        "reflected_flag": analysis["reflected_flag"],
        "significant_change": analysis["significant_change"],
        "vulnerability": analysis["vulnerability"],
        "verified": is_verified,
        "browser_checked": browser_checked,
        "rejected_candidate": rejected_class,
        "reward": reward,
        "current_state": str(current_state),
        "next_state": str(next_state),
    }
    return record, next_state, reward, verification_requests