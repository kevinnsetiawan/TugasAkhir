"""Oracle ground truth untuk benchmark detektor.

Tujuan modul ini: menyediakan label kerentanan yang DIBUAT MANUSIA dan
diperiksa manual terhadap Juice Shop, sehingga kualitas `ResponseAnalyzer`
dapat diukur tanpa bergantung pada agent RL. Tanpa oracle ini, metrik
"akurasi" apa pun yang dihitung dari log training bersifat circular: kode
detektor yang sama menjadi judges maupun yang dinilai.

PROVENANCE - BACA INI SEBELUM MELAPORKAN ANGKA
----------------------------------------------
Label di bawah berasal dari DAFTAR CHALLENGE PUBLIK Juice Shop, dipetakan ke
(endpoint, payload) lalu diperiksa ulang manual terhadap instance yang
berjalan: tiap entri dicek apakah payload benar-benar menghasilkan bukti
eksploitasi, bukan sekadar cocok signature.

BAGAIMANA INI BUKAN BUKTI KUALITAS DETEKTOR YANG SEPENUHNYA:

Konfirmasi manual memakai mekanisme yang SAMA dengan yang dipakai sistem:
kontrol-diferensial untuk sqli/fuzzing dan eksekusi DOM untuk XSS. Artinya
kesepakatan antara oracle dan detektor tidak independen sepenuhnya - keduanya
berpijak pada bukti eksploitasi yang serupa. Karena itu benchmark ini
mengukur KONSISTENSI dan ketiadaan false positive, bukan generalisasi ke
environment lain.

Konsekuensi yang harus disebut jujur di tesis: nilai perfect 1.0 di sini
DIPERCIARKAN secara konstruksi dan tidak boleh disajikan sebagai bukti bahwa
detektor sempurna. Yang bisa diklaim secara sah:
  - nol false positive pada 60 aksi berlabel negatif
  - detektor konsisten dengan ground truth yang dikurasi manual
  - quality gate (kontrol-diferensial + DOM) benar-benar menyaring kandidat

CATATAN KEJUJURAN LAIN: `payloads.json` dan gating `surface` di `config.py`
memang ditulis manusia yang sudah tahu struktur Juice Shop. Itu human prior,
bukan data leakage: agent tetap harus memilih payload yang tepat, dan setiap
temuan tetap wajib lolos kontrol-diferensial. Nyatakan eksplisit di tesis.
"""

from typing import Dict, FrozenSet, Tuple

# action_index = endpoint_index * N_PAYLOADS + payload_index
# N_PAYLOADS = 15 (lihat rl_pentest/data/payloads.json)
N_PAYLOADS = 15

# ---------------------------------------------------------------------------
# POSITIF: (endpoint_index, payload_index) yang terkonfirmasi eksploitabel.
#
# Daftar ini disusun DARI DOKUMENTASI RESMI JUICE SHOP (daftar challenge yang
# dipublikasikan) lalu dikonfirmasi ulang secara manual terhadap instance yang
# berjalan: setiap entri dicek apakah payload benar-benar menghasilkan bukti
# eksploitasi, bukan sekadar cocok signature.
#
# PENTING SOAL PROVENANCE: daftar ini disusun dari dokumentasi publik Juice
# Shop, bukan disalin dari log training. Cross-check dengan kolom `verified`
# di log hanya dipakai sebagai KONFIRMASI, bukan sumber. Lihat catatan
# KEJUJURAN di docstring module: konfirmasi memakai mekanisme yang sama dengan
# sistem, sehingga angka perfect 1.0 tidak boleh diklaim sebagai bukti
# generalisasi.
# ---------------------------------------------------------------------------
CONFIRMED_VULNERABLE: FrozenSet[Tuple[int, int]] = frozenset({
    # --- ep0: GET /rest/products/search?q=  (surface "sql") ---
    # Challenge "SQL Injection": kolom q dirangkai mentah ke LIKE (search.ts:23).
    # Tiap payload berikut membocorkan baris yang seharusnya tersaring.
    (0, 0),   # sqli_tautology -> dump seluruh tabel product
    (0, 1),   # sqli_comment   -> ' apple'-- menutup klausa, mengosongkan filter
    (0, 2),   # sqli_union     -> UNION SELECT NULL menggabungkan tabel
    (0, 3),   # sqli_time      -> SLEEP(5) / error sintaks SQL
    (0, 4),   # sqli_wildcard  -> %s%s%s membatalkan LIKE '%input%'
    # Challenge "Reflected XSS": /#/search merender queryParam via
    # bypassSecurityTrustHtml -> [innerHTML].
    (0, 6),   # xss_img    -> <img onerror> dieksekusi di /#/search
    (0, 9),   # xss_review -> payload JSON ter-render ke halaman hasil

    # --- ep1: GET /ftp/  (surface "file") ---
    # Challenge tersembunyi: /ftp/ hanya mengizinkan .md/.pdf, sehingga eksploitasi
    # nyata adalah poison null byte %2500 untuk membaca ekstensi terlarang.
    (1, 10),  # lfi_poison_null -> package.json.bak
    (1, 11),  # lfi_coupons      -> coupons_2013.md.bak
    (1, 12),  # lfi_wap_rules    -> suspicious_errors.yml

    # --- ep3: GET /rest/track-order/  (surface "plain", dirender ke DOM) ---
    # Challenge "Reflected XSS" (varian): /#/track-result merender orderId lewat
    # bypassSecurityTrustHtml (routes/trackOrder.ts:21-23). Endpoint membalas
    # JSON, jadi bukti hanya sah lewat eksekusi DOM.
    (3, 6),   # xss_img
    (3, 8),   # xss_svg
    (3, 9),   # xss_review

    # --- ep4: POST /rest/user/login  (surface "sql") ---
    # Challenge "SQL Injection" (login.ts:34): tautologi pada kolom email
    # mengembalikan 200 beserta token - bypass autentikasi.
    (4, 5),   # sqli_login
})

# ---------------------------------------------------------------------------
# NEGATIF TERCOCOKAN: endpoint berpermukaan "plain" yang SECARA TERBUKTI
# tidak punya injeksi. Ini yang membuat angka false-positive bermakna: bila
# detektor melaporkan vuln di salah satu kombinasi ini, itu false positive.
# Source: routes/search.ts, routes/login.ts hanya punya 2 sink SQL; handler
# reviews meng-escape HTML; sanitizeHtml mengosongkan Feedbacks.
# ---------------------------------------------------------------------------
KNOWN_SAFE_ENDPOINTS: FrozenSet[int] = frozenset({2, 5, 6, 7})


def expected_label(action_index: int, n_payloads: int = N_PAYLOADS) -> str:
    """Label ground truth untuk satu action_index.

    Mengembalikan "sqli" / "xss" / "fuzzing" untuk kombinasi yang terkonfirmasi
    eksploitabel, atau "none" untuk kombinasi yang aman. Endpoint di
    KNOWN_SAFE_ENDPOINTS yang tidak ada di daftar positif dijawab "none"
    dengan keyakinan tinggi; endpoint sql/file di luar daftar positif
    dijawab "unknown" agar tidak dihitung sebagai true negative.
    """
    endpoint_index = action_index // n_payloads
    payload_index = action_index % n_payloads
    pair = (endpoint_index, payload_index)

    if pair in CONFIRMED_VULNERABLE:
        return _class_of_payload(payload_index)
    if endpoint_index in KNOWN_SAFE_ENDPOINTS:
        return "none"
    # Endpoint berpermukaan sql/file yang belum terkonfirmasi: jangan
    # diasumsikan aman, karena "none" di sini bisa menginflasi specificity.
    return "unknown"


def _class_of_payload(payload_index: int) -> str:
    if payload_index in (0, 1, 2, 3, 4, 5):
        return "sqli"
    if payload_index in (6, 7, 8, 9):
        return "xss"
    return "fuzzing"


def ground_truth_summary(n_endpoints: int, n_payloads: int = N_PAYLOADS) -> Dict[str, object]:
    """Ringkasan oracle untuk dicetak pada laporan benchmark."""
    labels = [
        expected_label(a, n_payloads) for a in range(n_endpoints * n_payloads)
    ]
    positives = [
        a for a, label in enumerate(labels) if label in ("sqli", "xss", "fuzzing")
    ]
    unlabelled = [a for a, label in enumerate(labels) if label == "unknown"]
    return {
        "total_actions": n_endpoints * n_payloads,
        "positives": len(positives),
        "labelled_actions": len(labels) - len(unlabelled),
        "unlabelled_actions": len(unlabelled),
        "negatives": labels.count("none"),
        "known_safe_endpoints": sorted(KNOWN_SAFE_ENDPOINTS),
        "confirmed_actions": positives,
    }
