import os
import time

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
ITALIC = "\033[3m"
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
MAGENTA = "\033[35m"
BLUE = "\033[34m"
WHITE = "\033[37m"

LINE_WIDTH = 80


def init():
    if os.name == "nt":
        os.system("")


def ts():
    return time.strftime("%H:%M:%S")


def paint(text, *codes):
    return "".join(codes) + text + RESET


def rule(char="=", width=LINE_WIDTH):
    return paint(char * width, DIM, CYAN)


def thinline(width=LINE_WIDTH):
    return paint("-" * width, DIM, CYAN)


def pad(text, width=LINE_WIDTH):
    return text.ljust(width)


def tag(t):
    return paint("[%s]" % t, BOLD, CYAN)


def log(text, level="*", color=WHITE, prefix=""):
    line = "  %s %s %s%s" % (
        paint(ts(), DIM, BLUE),
        paint("[%s]" % level, BOLD, color),
        prefix,
        paint(text, color),
    )
    print(line)


def info(text):
    log(text, ">", CYAN)


def boot(text):
    log(text, "+", GREEN)


def warn(text):
    log(text, "!", YELLOW)


def error(text):
    log(text, "x", RED)


def ok(text):
    log(text, "+", GREEN)


def vuln(text):
    log(text, "+", GREEN)


def mask(text):
    log(text, "!", YELLOW)


BANNER_ART = {
    "Q-Learning": [
        "  _____      _               ______         _",
        " / ____|    | |             |  ____|       | |",
        "| |    _   _| |__   ___ _ __| |__ ___  _ __| |_ _ __ ___  ___ ___",
        "| |   | | | | '_ \\ / _ \\ '__|  __/ _ \\| '__| __| '__/ _ \\/ __/ __|",
        "| |___| |_| | |_) |  __/ |  | | | (_) | |  | |_| | |  __/\\__ \\__ \\",
        " \\_____\\__, |_.__/ \\___|_|  |_|  \\___/|_|   \\__|_|  \\___||___/___/",
        "        __/ |",
        "       |___/",
    ],
    "DQN": [
        " ____   ___  _   _",
        "|  _ \\ / _ \\| \\ | |",
        "| | | | | | |  \\| |",
        "| |_| | |_| | |\\  |",
        "|____/ \\__\\_\\_| \\_|",
    ],
}

TAGLINE = "~~ CyberFortress :: Reinforcement Learning Autonomous Web Pentest :: {} ~~"


def banner(agent="Q-Learning"):
    lines = [rule()]
    for a in BANNER_ART.get(agent, BANNER_ART["Q-Learning"]):
        lines.append(paint("  " + a, BOLD, GREEN))
    lines.append("  " + paint(TAGLINE.format(agent), ITALIC, MAGENTA))
    lines.append(rule())
    return "\n".join(lines)


def summary_block(title, pairs):
    lines = [rule(), "  " + paint(title, BOLD, CYAN), thinline()]
    for k, v in pairs:
        lines.append(
            "  %s %s%s"
            % (paint("[*]", BOLD, CYAN), paint(k.ljust(24), WHITE), paint(str(v), GREEN))
        )
    lines.append(rule())
    return "\n".join(lines)


def progress_bar(current, total, width=20):
    filled = int(width * current / total) if total else 0
    return "[%s%s]" % (paint("#" * filled, BOLD, GREEN), paint("." * (width - filled), DIM, BLUE))


# ─────────────────────────────────────────────────────────────────────────────
# TABEL ASCII TERSTRUKTUR
# ─────────────────────────────────────────────────────────────────────────────

def _hline(widths, left="├", mid="┼", right="┤", dash="─"):
    return left + mid.join(dash * (w + 2) for w in widths) + right


def _top(widths):
    return "┌" + "┬".join("─" * (w + 2) for w in widths) + "┐"


def _bottom(widths):
    return "└" + "┴".join("─" * (w + 2) for w in widths) + "┘"


def _row(cells, widths, bold_cols=None):
    bold_cols = bold_cols or []
    parts = []
    for i, (cell, w) in enumerate(zip(cells, widths)):
        s = str(cell)
        padded = s.ljust(w) if i == 0 else s.rjust(w)
        if i in bold_cols:
            padded = paint(padded, BOLD, GREEN)
        parts.append(" " + padded + " ")
    return "│" + "│".join(parts) + "│"


def _header_row(cells, widths):
    parts = [" " + paint(str(c).center(w), BOLD, CYAN) + " " for c, w in zip(cells, widths)]
    return "│" + "│".join(parts) + "│"


def table_summary(agent_label, summary, records=None):
    """Tabel ringkasan metrik kinerja utama setelah training selesai."""
    W = LINE_WIDTH
    title = f" RINGKASAN EKSEKUSI :: {agent_label} "
    print("\n" + paint("┌" + "─" * (W - 2) + "┐", BOLD, CYAN))
    print(paint("│" + title.center(W - 2) + "│", BOLD, CYAN))
    print(paint("├" + "─" * (W - 2) + "┤", BOLD, CYAN))

    # ── Blok 1: Anggaran & Permintaan
    print(paint("│" + paint(" ANGGARAN & PERMINTAAN HTTP".ljust(W - 2), BOLD, YELLOW) + "│", CYAN))
    rows_req = [
        ("Total Episode (Anggaran Penuh)",   summary.get("total_episodes", 0),                       False),
        ("Total Permintaan Payload",          summary.get("total_requests", 0),                       False),
        ("Permintaan Verifikasi",             summary.get("verification_requests", 0),                False),
        ("Permintaan Baseline Probe",         summary.get("baseline_probe_requests", 0),              False),
        ("Total Transaksi HTTP (w/ verif.)",  summary.get("total_requests_with_verification", 0),     True),
        ("Navigasi Peramban (XSS DOM)",       summary.get("browser_navigations", 0),                  False),
        ("Durasi Training",                   f"{summary.get('training_duration_seconds', 0):.2f} detik", False),
        ("Rata-rata Waktu Respons",           f"{summary.get('average_response_time', 0):.4f} detik", False),
    ]
    widths_2col = [46, W - 52]
    print(paint("│" + "┬".join("─" * (w + 2) for w in widths_2col) + "│", DIM, CYAN))
    for label, val, bold in rows_req:
        v = paint(str(val).rjust(widths_2col[1]), BOLD, GREEN) if bold else str(val).rjust(widths_2col[1])
        print("│ " + paint(str(label).ljust(widths_2col[0]), WHITE) + " │ " + v + " │")
    print(paint("│" + "┴".join("─" * (w + 2) for w in widths_2col) + "│", DIM, CYAN))

    # ── Blok 2: Temuan Kerentanan
    print(paint("│" + paint(" TEMUAN KERENTANAN TERVERIFIKASI".ljust(W - 2), BOLD, YELLOW) + "│", CYAN))
    rows_vuln = [
        ("SQL Injection",                     summary.get("sql_injection", 0),        True),
        ("Reflected XSS (DOM Verified)",      summary.get("reflected_xss", 0),        True),
        ("Fuzzing / File Disclosure",         summary.get("fuzzing_anomaly", 0),       True),
        ("TOTAL Kerentanan Terverifikasi",    summary.get("total_vulnerabilities", 0), True),
        ("Lokasi Unik (endpoint, kelas)",     summary.get("unique_vuln_locations", 0), False),
        ("Aksi Terverifikasi (dari 120)",     summary.get("discovered_actions", 0),    False),
        ("Kandidat Ditolak (false positive)", summary.get("rejected_candidates", 0),   False),
    ]
    print(paint("│" + "┬".join("─" * (w + 2) for w in widths_2col) + "│", DIM, CYAN))
    for label, val, bold in rows_vuln:
        v = paint(str(val).rjust(widths_2col[1]), BOLD, GREEN) if bold else str(val).rjust(widths_2col[1])
        print("│ " + paint(str(label).ljust(widths_2col[0]), WHITE) + " │ " + v + " │")
    print(paint("│" + "┴".join("─" * (w + 2) for w in widths_2col) + "│", DIM, CYAN))

    # ── Blok 3: Metrik Efisiensi
    print(paint("│" + paint(" METRIK EFISIENSI & PEMBELAJARAN".ljust(W - 2), BOLD, YELLOW) + "│", CYAN))
    hit = summary.get("vuln_hit_rate", 0)
    rpv = summary.get("requests_per_vulnerability", float("inf"))
    rpv_str = f"{rpv:.2f}" if rpv != float("inf") else "∞"
    rows_eff = [
        ("Vuln Hit Rate",                    f"{hit*100:.2f}%",                                       False),
        ("Request per Kerentanan",           rpv_str,                                                  True),
        ("Akumulasi Reward (Cumulative)",    summary.get("cumulative_reward", 0),                      False),
        ("Episode Temuan Pertama",           f"Episode {summary.get('time_to_first_vulnerability',0)}", False),
        ("Episode Semua Vuln Ditemukan",     f"Episode {summary.get('episode_all_discovered', 0)}",    False),
        ("State Unik di Q-Table",            summary.get("states_visited", "--"),                      False),
        ("Cakupan Metrik",                   summary.get("metrics_scope", "in-sample"),                False),
    ]
    print(paint("│" + "┬".join("─" * (w + 2) for w in widths_2col) + "│", DIM, CYAN))
    for label, val, bold in rows_eff:
        v = paint(str(val).rjust(widths_2col[1]), BOLD, GREEN) if bold else str(val).rjust(widths_2col[1])
        print("│ " + paint(str(label).ljust(widths_2col[0]), WHITE) + " │ " + v + " │")
    print(paint("│" + "┴".join("─" * (w + 2) for w in widths_2col) + "│", DIM, CYAN))

    print(paint("└" + "─" * (W - 2) + "┘", BOLD, CYAN))


def table_vuln_findings(records):
    """Tabel semua kerentanan terverifikasi yang ditemukan selama training."""
    vulns = [r for r in records if r.get("verified") and r.get("vulnerability") not in ("none", None, "")]
    if not vulns:
        warn("Tidak ada kerentanan terverifikasi yang ditemukan.")
        return

    VULN_LABEL_MAP = {"sqli": "SQL Injection", "xss": "XSS (DOM)", "fuzzing": "File Disclosure"}
    ENDPOINT_MAP = {
        "0": "/rest/products/search", "1": "/ftp/", "2": "/rest/products/1/reviews",
        "3": "/rest/track-order/",    "4": "/rest/user/login", "5": "/rest/products/1/reviews (PUT)",
        "6": "/api/Feedbacks",        "7": "/api/Challenges",
    }

    W = LINE_WIDTH + 30
    title = f" DAFTAR KERENTANAN TERVERIFIKASI ({len(vulns)} TEMUAN) "
    print("\n" + paint("┌" + "─" * (W - 2) + "┐", BOLD, GREEN))
    print(paint("│" + title.center(W - 2) + "│", BOLD, GREEN))

    # Header
    cols   = ["No", "Episode", "Endpoint", "Kategori", "Muatan Uji (Payload)", "Status", "Reward", "Bukti"]
    widths = [3, 7, 30, 16, 38, 6, 6, 12]
    print(paint("├" + "┬".join("─" * (w + 2) for w in widths) + "┤", BOLD, GREEN))
    hdr = "│" + "│".join(" " + paint(c.center(w), BOLD, CYAN) + " " for c, w in zip(cols, widths)) + "│"
    print(hdr)
    print(paint("├" + "┼".join("─" * (w + 2) for w in widths) + "┤", BOLD, GREEN))

    # Baris data
    ep_map = {}
    for i, r in enumerate(records):
        ep_map[id(r)] = i + 1

    for n, r in enumerate(vulns, 1):
        ep_num   = ep_map.get(id(r), "?")
        ep_idx   = str(r.get("endpoint_index", "?"))
        endpoint = ENDPOINT_MAP.get(ep_idx, f"ep{ep_idx}")
        kategori = VULN_LABEL_MAP.get(r.get("vulnerability", ""), r.get("vulnerability", ""))
        payload  = str(r.get("payload", ""))[:36] + (".." if len(str(r.get("payload",""))) > 36 else "")
        status   = str(r.get("status_code", ""))
        reward   = str(r.get("reward", ""))
        # Tentukan bukti
        bukti = "DOM-exec" if r.get("browser_checked") else \
                "err_flag" if r.get("error_flag") else \
                "sig_chg"  if r.get("significant_change") else "verified"

        cells = [str(n), str(ep_num), endpoint, kategori, payload, status, reward, bukti]
        bold_cols = [3, 6]  # kategori dan reward
        row_parts = []
        for i, (cell, w) in enumerate(zip(cells, widths)):
            s = str(cell)
            padded = s.rjust(w) if i in (0, 1, 5, 6) else s.ljust(w)
            if i in bold_cols:
                padded = paint(padded, BOLD, GREEN)
            elif i == 3:
                color = YELLOW if "SQL" in s else (MAGENTA if "XSS" in s else CYAN)
                padded = paint(padded, BOLD, color)
            row_parts.append(" " + padded + " ")
        print("│" + "│".join(row_parts) + "│")

    print(paint("└" + "┴".join("─" * (w + 2) for w in widths) + "┘", BOLD, GREEN))


def table_per_endpoint(records, n_endpoints=8):
    """Tabel distribusi permintaan dan temuan per endpoint."""
    ENDPOINT_PATHS = [
        "/rest/products/search?q=", "/ftp/", "/rest/products/1/reviews",
        "/rest/track-order/",       "/rest/user/login", "/rest/products/1/reviews (PUT)",
        "/api/Feedbacks",           "/api/Challenges",
    ]
    METHODS = ["GET", "GET", "GET", "GET", "POST", "PUT", "POST", "GET"]

    counts  = {i: 0 for i in range(n_endpoints)}
    sqli    = {i: 0 for i in range(n_endpoints)}
    xss     = {i: 0 for i in range(n_endpoints)}
    fuzz    = {i: 0 for i in range(n_endpoints)}

    for r in records:
        ep = int(r.get("endpoint_index", 0))
        counts[ep] = counts.get(ep, 0) + 1
        if r.get("verified") and r.get("vulnerability") not in ("none", None, ""):
            v = r.get("vulnerability", "")
            if v == "sqli":    sqli[ep]  = sqli.get(ep, 0) + 1
            elif v == "xss":   xss[ep]   = xss.get(ep, 0) + 1
            elif v == "fuzzing": fuzz[ep] = fuzz.get(ep, 0) + 1

    W = LINE_WIDTH + 20
    title = " DISTRIBUSI PERMINTAAN & TEMUAN PER ENDPOINT "
    print("\n" + paint("┌" + "─" * (W - 2) + "┐", BOLD, CYAN))
    print(paint("│" + title.center(W - 2) + "│", BOLD, CYAN))

    cols   = ["Idx", "Metode", "Endpoint / Path", "Request", "SQLi", "XSS", "Fuzz", "Total"]
    widths = [3, 5, 36, 9, 5, 5, 5, 7]
    print(paint("├" + "┬".join("─" * (w + 2) for w in widths) + "┤", BOLD, CYAN))
    hdr = "│" + "│".join(" " + paint(c.center(w), BOLD, CYAN) + " " for c, w in zip(cols, widths)) + "│"
    print(hdr)
    print(paint("├" + "┼".join("─" * (w + 2) for w in widths) + "┤", BOLD, CYAN))

    total_req = total_sqli = total_xss = total_fuzz = 0
    for i in range(n_endpoints):
        tot = sqli[i] + xss[i] + fuzz[i]
        total_req  += counts[i]
        total_sqli += sqli[i]
        total_xss  += xss[i]
        total_fuzz += fuzz[i]
        path = ENDPOINT_PATHS[i] if i < len(ENDPOINT_PATHS) else f"ep{i}"
        meth = METHODS[i] if i < len(METHODS) else "?"
        tot_str = paint(str(tot).rjust(7), BOLD, GREEN) if tot > 0 else str(tot).rjust(7)
        req_str = paint(str(counts[i]).rjust(9), BOLD, YELLOW) if counts[i] > 100 else str(counts[i]).rjust(9)
        cells_str = [
            str(i).rjust(3),
            meth.center(5),
            path.ljust(36),
            req_str,
            str(sqli[i]).rjust(5),
            str(xss[i]).rjust(5),
            str(fuzz[i]).rjust(5),
            tot_str,
        ]
        print("│ " + " │ ".join(cells_str) + " │")

    # Baris total
    print(paint("├" + "┼".join("─" * (w + 2) for w in widths) + "┤", DIM, CYAN))
    grand_tot = total_sqli + total_xss + total_fuzz
    print("│ " + " │ ".join([
        paint("TOT", BOLD, CYAN).rjust(3),
        "".center(5),
        paint("TOTAL".ljust(36), BOLD, CYAN),
        paint(str(total_req).rjust(9), BOLD, YELLOW),
        paint(str(total_sqli).rjust(5), BOLD, GREEN),
        paint(str(total_xss).rjust(5), BOLD, GREEN),
        paint(str(total_fuzz).rjust(5), BOLD, GREEN),
        paint(str(grand_tot).rjust(7), BOLD, GREEN),
    ]) + " │")
    print(paint("└" + "┴".join("─" * (w + 2) for w in widths) + "┘", BOLD, CYAN))