from typing import List, Dict

VULN_TYPES = {"sqli": "SQL Injection", "xss": "Reflected XSS", "fuzzing": "Fuzzing Anomaly"}


def compute_metrics(logs: List[Dict[str, object]]) -> Dict[str, object]:
    """Metrik dari log training.

    PENTING - semua angka di sini adalah IN-SAMPLE: dihitung dari episode yang
    sama dengan yang dipakai agent untuk belajar. Angka ini menggambarkan
    perilaku agent pada target itu, bukan generalisasi ke instance lain.
    Untuk kualitas detektor yang tidak circular, jalankan
    `python benchmark_detector.py` yang membandingkan ResponseAnalyzer dengan
    oracle ground truth manual.
    """
    total_requests = len(logs)
    total_reward = sum(int(row.get("reward", 0)) for row in logs)
    # Hanya temuan yang lolos verifikasi yang dihitung sebagai kerentanan.
    # Kolom 'verified' bernilai False pada episode tanpa temuan maupun pada
    # kandidat yang ditolak, sehingga harus menjadi gerbang wajib di sini.
    confirmed = [
        (i, row) for i, row in enumerate(logs)
        if row.get("vulnerability") in VULN_TYPES and row.get("verified")
    ]
    sql_injection = sum(1 for _, row in confirmed if row.get("vulnerability") == "sqli")
    reflected_xss = sum(1 for _, row in confirmed if row.get("vulnerability") == "xss")
    fuzzing_anomaly = sum(1 for _, row in confirmed if row.get("vulnerability") == "fuzzing")
    total_vulns = sql_injection + reflected_xss + fuzzing_anomaly
    total_positive = len(confirmed)
    positive_episodes = [i + 1 for i, _ in confirmed]
    unique_locations = {(row.get("endpoint_index"), row.get("vulnerability")) for _, row in confirmed}
    time_to_first_vulnerability = positive_episodes[0] if positive_episodes else None
    episode_all_discovered = max(positive_episodes) if positive_episodes else None
    average_response_time = 0.0
    response_times = [float(row.get("response_time", 0.0)) for row in logs if row.get("response_time") is not None]
    if response_times:
        average_response_time = sum(response_times) / len(response_times)
    # Porsi episode yang menghasilkan temuan terverifikasi. Ini BUKAN precision
    # ML (tp / (tp + fp)): yang dihitung adalah hit rate per request.
    vuln_hit_rate = float(total_positive) / total_requests if total_requests else 0.0
    request_per_vulnerability = float(total_requests) / total_vulns if total_vulns else float("inf")

    # Kandidat yang ditolak kontrol-diferensial atau gagal dieksekusi browser.
    # Dilaporkan sebagai JUMLAH, bukan rasio: "detection_accuracy =
    # vuln / (vuln + rejected)" selalu bernilai 1.0 selama tidak ada yang
    # ditolak, sehingga menyesatkan dan tidak dipakai lagi.
    rejected_candidates = sum(1 for row in logs if row.get("rejected_candidate") not in (None, "", "none"))
    browser_checked = sum(1 for row in logs if row.get("browser_checked"))

    return {
        "metrics_scope": "in-sample (dihitung dari episode training, bukan held-out)",
        "total_requests": total_requests,
        "total_vulnerabilities": total_vulns,
        "sql_injection": sql_injection,
        "reflected_xss": reflected_xss,
        "fuzzing_anomaly": fuzzing_anomaly,
        "cumulative_reward": total_reward,
        "vuln_hit_rate": round(vuln_hit_rate, 4),
        "average_response_time": round(average_response_time, 4),
        "requests_per_vulnerability": round(request_per_vulnerability, 4),
        "time_to_first_vulnerability": time_to_first_vulnerability,
        "episode_all_discovered": episode_all_discovered,
        "unique_vuln_locations": len(unique_locations),
        "rejected_candidates": rejected_candidates,
        "browser_checked_episodes": browser_checked,
    }
