import random
from collections import deque
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

STATUS_CATEGORIES = ["2xx", "3xx", "4xx", "5xx", "error"]
CONTENT_TYPE_CATEGORIES = ["json", "html", "text", "xml", "other"]


class DQNNetwork(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def encode_state(state) -> np.ndarray:
    status, length_cat, error, reflected, vuln, endpoint_idx, resp_time_cat, content_cat = state
    status_onehot = [1.0 if s == status else 0.0 for s in STATUS_CATEGORIES]
    length_onehot = [1.0 if i == length_cat else 0.0 for i in range(4)]
    endpoint_onehot = [1.0 if i == endpoint_idx else 0.0 for i in range(8)]
    resp_time_onehot = [1.0 if i == resp_time_cat else 0.0 for i in range(3)]
    content_onehot = [1.0 if i == content_cat else 0.0 for i in range(5)]
    return np.array(
        status_onehot + length_onehot + [error, reflected, vuln]
        + endpoint_onehot + resp_time_onehot + content_onehot,
        dtype=np.float32,
    )


class ReplayBuffer:
    def __init__(self, capacity: int = 10000):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action: int, reward: float, next_state, done: bool):
        self.buffer.append((
            encode_state(state),
            action,
            reward,
            encode_state(next_state),
            done,
        ))

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, min(batch_size, len(self.buffer)))
        states, actions, rewards, next_states, dones = zip(*batch)
        return (
            torch.FloatTensor(np.array(states)),
            torch.LongTensor(actions).unsqueeze(1),
            torch.FloatTensor(rewards).unsqueeze(1),
            torch.FloatTensor(np.array(next_states)),
            torch.FloatTensor(dones).unsqueeze(1),
        )

    def __len__(self) -> int:
        return len(self.buffer)


class DQNAgent:
    def __init__(
        self,
        n_actions: int,
        input_dim: int = 28,
        hidden_dim: int = 64,
        alpha: float = 0.001,
        gamma: float = 0.9,
        epsilon: float = 1.0,
        min_epsilon: float = 0.1,
        decay: float = 0.95,
        batch_size: int = 32,
        target_update_interval: int = 10,
        replay_capacity: int = 10000,
    ):
        self.n_actions = n_actions
        self.gamma = gamma
        self.epsilon = epsilon
        self.min_epsilon = min_epsilon
        self.decay = decay
        self.batch_size = batch_size
        self.target_update_interval = target_update_interval
        self.step_count = 0

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.policy_net = DQNNetwork(input_dim, hidden_dim, n_actions).to(self.device)
        self.target_net = DQNNetwork(input_dim, hidden_dim, n_actions).to(self.device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=alpha)
        self.loss_fn = nn.MSELoss()
        self.replay_buffer = ReplayBuffer(replay_capacity)

    def choose_action(self, state, mask=None) -> int:
        allowed = [i for i in range(self.n_actions) if not mask or i not in mask]
        if not allowed:
            allowed = list(range(self.n_actions))
        if random.random() < self.epsilon:
            return random.choice(allowed)
        state_t = torch.FloatTensor(encode_state(state)).unsqueeze(0).to(self.device)
        with torch.no_grad():
            q_values = self.policy_net(state_t)
        return int(max(allowed, key=lambda a: q_values[0, a].item()))

    def learn(self, state, action: int, reward: float, next_state):
        self.replay_buffer.push(state, action, reward, next_state, done=False)
        if len(self.replay_buffer) < self.batch_size:
            return

        states, actions, rewards, next_states, dones = self.replay_buffer.sample(self.batch_size)
        states = states.to(self.device)
        actions = actions.to(self.device)
        rewards = rewards.to(self.device)
        next_states = next_states.to(self.device)
        dones = dones.to(self.device)

        current_q = self.policy_net(states).gather(1, actions)
        with torch.no_grad():
            max_next_q = self.target_net(next_states).max(dim=1, keepdim=True)[0]
            target_q = rewards + self.gamma * max_next_q * (1 - dones)

        loss = self.loss_fn(current_q, target_q)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        self.step_count += 1
        if self.step_count % self.target_update_interval == 0:
            self.target_net.load_state_dict(self.policy_net.state_dict())

    def decay_exploration(self):
        self.epsilon = max(self.min_epsilon, self.epsilon * self.decay)

    def save_model(self, path: str):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save({
            "policy_net": self.policy_net.state_dict(),
            "target_net": self.target_net.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "epsilon": self.epsilon,
        }, path)

    def load_model(self, path: str):
        path = Path(path)
        if path.exists():
            checkpoint = torch.load(path, map_location=self.device)
            self.policy_net.load_state_dict(checkpoint["policy_net"])
            self.target_net.load_state_dict(checkpoint["target_net"])
            self.optimizer.load_state_dict(checkpoint["optimizer"])
            self.epsilon = checkpoint["epsilon"]
            return True
        return False
