from config import (
    LENGTH_REWARD_BONUS,
    REWARD_ANOMALY,
    REWARD_NONE,
    REWARD_REQUEST_ERROR,
    REWARD_VULNERABILITY,
)


class RewardSystem:
    def _length_bonus(self, analysis: dict) -> int:
        cat = analysis.get("length_category", 1)
        if 0 <= cat < len(LENGTH_REWARD_BONUS):
            return LENGTH_REWARD_BONUS[cat]
        return 0

    def compute_reward(self, analysis: dict, verified: bool = True) -> int:
        if analysis.get("request_error"):
            return REWARD_REQUEST_ERROR

        vulnerability = analysis.get("vulnerability", "none")
        if vulnerability in {"sqli", "xss", "fuzzing"}:
            base = REWARD_VULNERABILITY
            if not verified:
                base = REWARD_ANOMALY
        elif analysis.get("error_flag") or analysis.get("reflected_flag") or analysis.get("significant_change"):
            base = REWARD_ANOMALY
        else:
            base = REWARD_NONE

        return base + self._length_bonus(analysis)
