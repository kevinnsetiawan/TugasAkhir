import csv
import json
from pathlib import Path
from typing import List, Dict

class ResultLogger:
    def __init__(self, csv_path: str, summary_path: str):
        self.csv_path = Path(csv_path)
        self.summary_path = Path(summary_path)
        self.csv_path.parent.mkdir(parents=True, exist_ok=True)
        self.summary_path.parent.mkdir(parents=True, exist_ok=True)

    def write_csv(self, rows: List[Dict[str, object]]):
        if not rows:
            return
        fieldnames = list(rows[0].keys())
        with self.csv_path.open("w", encoding="utf-8", newline="") as csv_handle:
            writer = csv.DictWriter(csv_handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def write_summary(self, summary: Dict[str, object]):
        with self.summary_path.open("w", encoding="utf-8") as json_handle:
            json.dump(summary, json_handle, indent=2)
