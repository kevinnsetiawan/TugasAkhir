from pathlib import Path

# Konfigurasi dasar untuk proyek RL Pentest.
BASE_URL = "http://localhost:3000"

# Seluruh endpoint diverifikasi hidup terhadap Juice Shop v20.2.0. Endpoint yang
# mengembalikan "Unexpected path" atau 500 permanen dihapus karena tidak pernah
# dapat menghasilkan temuan dan hanya menghabiskan anggaran request.
ENDPOINTS = [
    # Dua-dua sink SQL injection di seluruh aplikasi (routes/search.ts:23 dan
    # routes/login.ts:34). Halaman /#/search me-render nilai query dengan
    # bypassSecurityTrustHtml sehingga vektor XSS terefleksi ke DOM.
    {"path": "/rest/products/search", "param": "q", "method": "GET", "surface": "sql"},
    # Server berkas. Hanya .md/.pdf yang diizinkan, sehingga eksploitasi nyata
    # adalah pemotongan poison null byte (%2500) untuk membaca berkas ekstensi
    # terlarang (routes/fileServer.ts:26-32).
    {"path": "/ftp/", "param": "path", "method": "GET", "surface": "file"},
    # Pembacaan review memakai MarsDB; payload masuk ke query string sehingga
    # handler mengabaikannya dan respons tetap 200 (kontrol hidup, bukan 500).
    {"path": "/rest/products/1/reviews", "param": "id", "method": "GET", "surface": "plain"},
    # ordersCollection MarsDB; orderId dirender lewat bypassSecurityTrustHtml
    # pada halaman /#/track-result (routes/trackOrder.ts:21-23).
    {"path": "/rest/track-order/", "param": "path", "method": "GET", "surface": "plain"},
    {"path": "/rest/user/login", "param": "json", "method": "POST", "surface": "sql"},
    # Reviews memakai interpolasi {{ review.message }} sehingga meng-escape HTML;
    # dipakai sebagai kontrol negatif (payload tersimpan tapi tidak dieksekusi).
    {"path": "/rest/products/1/reviews", "param": "json", "method": "PUT", "surface": "plain"},
    # Feedback dikosongkan oleh sanitizeHtml, dipakai sebagai kontrol negatif.
    # Endpoint ini mewajibkan rating dan CAPTCHA dua langkah.
    {"path": "/api/Feedbacks", "param": "json", "method": "POST",
     "captcha": True, "defaults": {"rating": 1, "UserId": 1}, "surface": "plain"},
    # API data besar tanpa autentikasi; menambah keragaman state & panjang respons.
    {"path": "/api/Challenges", "param": "q", "method": "GET", "surface": "plain"},
]

# Permukaan serang per endpoint, diturunkan dari kode sumber Juice Shop v20.2.0
# (bukan dari tebakan bentuk respons):
#   "sql"  -> input dirangkai ke klausa SQL mentah (routes/search.ts:23,
#             routes/login.ts:34). Hanya dua titik ini di seluruh aplikasi.
#   "file" -> presented file dari cakram dengan penyaring ekstensi.
#   "plain"-> input tidak masuk ke kueri mentah dan tidak presented file.
# Deklarasi ini hanya menyatakan DI MANA permukaan itu ada; agent tetap harus
# memilih payload yang tepat, dan tiap temuan tetap wajib lolos bukti
# eksploitasi plus verifikasi kontrol-diferensial. Mendeclare permukaan bukan
# berarti declare kerentanan: /rest/products/search tetap bisa dijawab 'none'
# bila tidak ada payload yang membocorkan data.
REQUEST_TIMEOUT = 10

# Halaman frontend yang benar-benar mengeksekusi vektor untuk endpoint tertentu.
# Kunci = endpoint_index, nilai = template path dengan placeholder {payload}.
# Diverifikasi terhadap frontend/src/app:
#   search-result.component.ts  -> bypassSecurityTrustHtml(queryParam)  -> [innerHTML]
#   track-result.component.ts   -> bypassSecurityTrustHtml(orderId)      -> [innerHtml]
XSS_PAGES = {
    0: "/#/search?q={payload}",
    3: "/#/track-result?id={payload}",
}

# Budget tetap 1585 request agar perbandingan dengan ZAP apples-to-apples.
# 1 episode = 1 request payload; pelatihan memakai SELURUH budget tanpa
# early-stop, sehingga hasil mencerminkan pembelajaran, bukan sapuan brute-force.
TOTAL_EPISODES = 1585

# Hyperparameter Q-Learning (Proposal Tabel 3.5)
ALPHA = 0.1
GAMMA = 0.9
EPSILON_START = 1.0
EPSILON_MIN = 0.1
EPSILON_DECAY = 0.90
OPTIMISTIC_INIT = 5.0

# Hyperparameter DQN.
#
# Catatan metodologis: decay DQN TIDAK boleh sama dengan Q-Learning. Dengan
# decay 0.90 per episode, eps 1.0 -> 0.1 hanya membutuhkan ~22 episode, jadi
# 98% anggaran berjalan pada eps = 0.1 (hampir deterministik). Karena
# policy_net DQN diinisialisasi acak, argmax Q pada episode awal condong ke
# satu index dan policy cepat "stuck": pada run sebelumnya 40% budget terbuang
# ke endpoint yang tidak punya kerentanan.
#
# Decay 0.9965 menurunkan eps ke 0.1 sekitar episode 1000, sehingga agent
# masih mengeksplorasi hampir sepanjang anggaran. Nilai ini TIDAK dibagi dengan
# Q-Learning supaya perbandingan tetap adil: dua algoritma dengan setting
# eksplorasi masing-masing yang wajar.
DQN_LR = 0.001
DQN_EPSILON_DECAY = 0.9965
DQN_BATCH_SIZE = 32
DQN_HIDDEN_DIM = 64
DQN_REPLAY_CAPACITY = 10000
DQN_TARGET_UPDATE_INTERVAL = 10

# Action masking: HANYA aksi dengan kerentanan terverifikasi yang di-mask.
# Aksi non-eksploitatif TIDAK di-mask permanen (tidak ada anti-repetisi
# berbasis hitungan gagal). Kebijakan ini membuat hasil discovery bergantung
# pada pembelajaran (exploitation vs exploration) daripada sapuan brute-force,
# sehingga Q-Learning dan DQN dapat dibandingkan secara bermakna.
# Pelatihan memakai SELURUH budget episode tanpa early-stop.

# Lokasi penyimpanan hasil dan data
ROOT_DIR = Path(__file__).resolve().parent
DATA_DIR = ROOT_DIR / "data"
QTABLE_DIR = ROOT_DIR / "qtable"
RESULTS_DIR = ROOT_DIR / "results"
PAYLOADS_FILE = DATA_DIR / "payloads.json"
QTABLE_FILE = QTABLE_DIR / "q_table.json"

# File output terpisah per agent agar hasil Q-Learning dan DQN tidak saling menimpa.
QL_CSV_LOG_FILE = RESULTS_DIR / "log_ql.csv"
QL_SUMMARY_FILE = RESULTS_DIR / "summary_ql.json"
DQN_CSV_LOG_FILE = RESULTS_DIR / "log_dqn.csv"
DQN_SUMMARY_FILE = RESULTS_DIR / "summary_dqn.json"

# Alias lama (diarahkan ke Q-Learning sebagai produk utama).
CSV_LOG_FILE = QL_CSV_LOG_FILE
SUMMARY_FILE = QL_SUMMARY_FILE

# Reward system (Tabel 3.5 Proposal)
REWARD_VULNERABILITY = 50
REWARD_ANOMALY = 10
REWARD_NONE = -1
REWARD_REQUEST_ERROR = -5

# Baseline OWASP ZAP
ZAP_API_URL = "http://localhost:8080"
ZAP_API_KEY = ""

# Threshold respons
LENGTH_SIGNIFICANT_RATIO = 0.15
DEFAULT_BASELINE_LENGTH = 2200
RESPONSE_TIME_SLOW = 2.0
RESPONSE_TIME_MEDIUM = 0.5

# Length categories (bytes)
LENGTH_CATEGORY_BINS = [1500, 2500, 3500]
LENGTH_REWARD_BONUS = [0, 0, 5, 10]

# Streamlit dashboard
DASHBOARD_TITLE = "Dashboard RL Automated Web Penetration Testing"
