import json
from pathlib import Path
from typing import Dict, List, Tuple

class PayloadGenerator:
    def __init__(self, payloads_file: str, n_endpoints: int = 1):
        self.payloads_file = Path(payloads_file)
        self.payloads = self._load_payloads()
        self.n_endpoints = n_endpoints
        self.n_payloads = len(self.payloads)

    def _load_payloads(self) -> List[Dict[str, str]]:
        with open(self.payloads_file, "r", encoding="utf-8") as handle:
            return json.load(handle)

    def get_action_count(self) -> int:
        return self.n_payloads * self.n_endpoints

    def get_payload(self, action_index: int) -> Dict[str, str]:
        if action_index < 0 or action_index >= self.get_action_count():
            raise IndexError("Action index di luar jangkauan payload")
        payload_index = action_index % self.n_payloads
        return self.payloads[payload_index]

    def get_payload_and_endpoint(self, action_index: int) -> Tuple[Dict[str, str], int]:
        if action_index < 0 or action_index >= self.get_action_count():
            raise IndexError("Action index di luar jangkauan payload")
        endpoint_index = action_index // self.n_payloads
        payload_index = action_index % self.n_payloads
        return self.payloads[payload_index], endpoint_index

    def get_action_name(self, action_index: int) -> str:
        return self.get_payload(action_index)["name"]

    def get_payload_text(self, action_index: int) -> str:
        return self.get_payload(action_index)["payload"]

    def list_payloads(self) -> List[str]:
        return [payload["payload"] for payload in self.payloads]
