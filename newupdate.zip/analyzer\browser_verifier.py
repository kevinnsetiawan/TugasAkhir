"""Verifikasi eksekusi XSS berbasis browser headless.

Refleksi payload pada respons HTTP saja BUKAN bukti kerentanan: Juice Shop
menyimpan payload review sebagai JSON (yang tidak dieksekusi browser) sekaligus
me-render-nya sebagai HTML tanpa sanitasi pada halaman lain. Karena itu kelas
XSS di sini hanya diakui bila vektor benar-benar dieksekusi di dalam DOM.

Teknik: vektor/instrumentasi mempertahankan bentuk vektor (tag dan event yang
sama) tetapi mengganti isi handler dengan penanda global. Bila DOM mengeksekusi
vektor, penanda terpasang dan temuan diterima. Dialog alert() juga ditangkap
sebagai bukti cadangan untuk vektor yang tidak dapat diinstrumentasi.
"""
import re
import time
from typing import Optional
from urllib.parse import quote

CANARY_JS = "window.__RLP_XSS_CANARY__=1"
CANARY_CHECK = "() => !!window.__RLP_XSS_CANARY__"
POLL_INTERVAL_MS = 200

_EVENT_ATTR = re.compile(r"(on[a-zA-Z]+\s*=\s*)(\"[^\"]*\"|'[^']*'|[^\s>]+)")
_SCRIPT_TAG = re.compile(r"(<script[^>]*>)(.*?)(</script>)", re.IGNORECASE | re.DOTALL)
_JS_URI = re.compile(r"(javascript:)(.*)", re.IGNORECASE)


def instrument(payload: str) -> Optional[str]:
    """Ganti isi handler vektor dengan penanda, mempertahankan bentuknya.
    Return None bila bentuk vektor tidak dikenali."""
    if not payload:
        return None

    def _mark_event(match):
        quote_char = ""
        value = match.group(2)
        if value[:1] in ("'", '"'):
            quote_char = value[0]
        return f"{match.group(1)}{quote_char}{CANARY_JS}{quote_char}"

    if _EVENT_ATTR.search(payload):
        return _EVENT_ATTR.sub(_mark_event, payload, count=1)

    if _SCRIPT_TAG.search(payload):
        return _SCRIPT_TAG.sub(lambda m: f"{m.group(1)}{CANARY_JS}{m.group(3)}", payload, count=1)

    if _JS_URI.search(payload):
        return _JS_URI.sub(lambda m: f"{m.group(1)}{CANARY_JS}", payload, count=1)

    return None


class BrowserVerifier:
    """Verifier XSS headless dengan instance browser yang dipakai ulang dan
    cache hasil, sehingga verifikasi berulang atas vektor yang sama tidak
    memerlukan navigasi baru."""

    def __init__(self, base_url: str, timeout: int = 30, settle_seconds: float = 4.0,
                 attempts: int = 3):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout * 1000
        self.settle_seconds = settle_seconds
        self.attempts = max(1, attempts)
        self._playwright = None
        self._browser = None
        self._cache: dict = {}
        self.navigations = 0
        self.available = True
        self.unavailable_reason = ""

    def _ensure_browser(self) -> bool:
        if self._browser is not None:
            return True
        if not self.available:
            return False
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as error:
            self.available = False
            self.unavailable_reason = f"playwright tidak terpasang: {error}"
            return False
        try:
            self._playwright = sync_playwright().start()
            self._browser = self._playwright.chromium.launch()
        except Exception as error:  # noqa: BLE001 - kegagalan runtime di sini berarti verifikasi tidak mungkin
            self.available = False
            self.unavailable_reason = f"chromium tidak dapat dijalankan: {error}"
            self.close()
            return False
        self._warmup()
        return True

    def _warmup(self):
        """Muat SPA Juice Shop sekali sebelum probing.

        Tanpa ini, probe pertama pada browser baru berada di bawah tekanan
        unduhan aset: rendering halaman tertahan sehingga handler vektor belum
        sempat dieksekusi saat jendela deteksi ditutup. Gejalanya bukan vektor
        yang gagal, melainkan verdict acak yang hanya muncul di awal run. Setelah
        aset ter-cache, setiap vektor menghasilkan verdict yang konsisten."""
        page = None
        try:
            page = self._browser.new_page()
            page.goto(self.base_url, wait_until="domcontentloaded", timeout=self.timeout)
            page.wait_for_timeout(int(self.settle_seconds * 500))
        except Exception:  # noqa: BLE001 - warmup hanya optimasi, bukan syarat verifikasi
            pass
        finally:
            if page is not None:
                try:
                    page.close()
                except Exception:  # noqa: BLE001
                    pass

    def build_url(self, page_path: str, payload: str) -> str:
        return f"{self.base_url}{page_path.format(payload=quote(payload, safe=''))}"

    def _await_canary(self, page) -> bool:
        """Tunggu penanda terpasang dalam jendela waktu terbatas.

        Dua sumber ketidakstabilan ditangani di sini:
        1. Vektor seperti <svg onload=...> bersifat race-prone di Chromium,
           sehingga satu jeda-tetap tidak cukup. Polling berhenti segera
           setelah bukti ditemukan.
        2. SPA Juice Shop mengganti execution context saat merender hasil,
           sehingga evaluate() sempat melempar 'context destroyed'._error itu
           BUKAN bukti ketiadaan XSS; polling dilanjutkan sampai deadline
           agar verdict tidak bergantung pada race internal halaman."""
        deadline = time.monotonic() + self.settle_seconds
        while True:
            try:
                if page.evaluate(CANARY_CHECK):
                    return True
            except Exception:  # noqa: BLE001 - context hilang, coba lagi
                pass
            if time.monotonic() >= deadline:
                return False
            try:
                page.wait_for_timeout(POLL_INTERVAL_MS)
            except Exception:  # noqa: BLE001 - halaman ditutup, tidak ada yang bisa dicek
                return False

    def verify(self, page_path: str, payload: str) -> bool:
        """True bila vektor benar-benar dieksekusi oleh DOM halaman.

        Sebagian vektor (mis. <svg onload=...> yang disisipkan lewat innerHTML)
        hanya fire pada sebagian render, sehingga satu percobaan menghasilkan
        verdict yang tidak reproducible. Karena itu vektor dicoba sampai
        `attempts` kali dan dianggap dieksekusi bila pernah teramati benar-benar
        berjalan. Kompromi ini condong ke under-reporting, bukan
        over-reporting, dan membuat verdict stabil antar-run."""
        key = (page_path, payload)
        if key in self._cache:
            return self._cache[key]

        if not self._ensure_browser():
            self._cache[key] = False
            return False

        probe = instrument(payload) or payload
        executed = False
        for _ in range(self.attempts):
            if self._probe_once(page_path, probe):
                executed = True
                break

        self._cache[key] = executed
        return executed

    def _probe_once(self, page_path: str, probe: str) -> bool:
        page = None
        try:
            page = self._browser.new_page()

            def _on_dialog(dialog):
                # alert() yang dieksekusi vektor adalah bukti eksekusi juga,
                # dipakai saat payload tidak dapat diinstrumentasi.
                dialog.dismiss()
                page.evaluate(CANARY_JS)

            page.on("dialog", _on_dialog)
            self.navigations += 1
            page.goto(self.build_url(page_path, probe), wait_until="domcontentloaded", timeout=self.timeout)
            return self._await_canary(page)
        except Exception:  # noqa: BLE001 - halaman gagal dimuat bukan bukti XSS
            return False
        finally:
            if page is not None:
                try:
                    page.close()
                except Exception:  # noqa: BLE001
                    pass

    def close(self):
        for closer in (getattr(self._browser, "close", None), getattr(self._playwright, "stop", None)):
            if closer is None:
                continue
            try:
                closer()
            except Exception:  # noqa: BLE001
                pass
        self._browser = None
        self._playwright = None
