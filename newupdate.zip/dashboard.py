import json
from pathlib import Path

import pandas as pd
import streamlit as st

from config import (
    DASHBOARD_TITLE,
    DQN_CSV_LOG_FILE,
    DQN_SUMMARY_FILE,
    QL_CSV_LOG_FILE,
    QL_SUMMARY_FILE,
)


def load_summary(path):
    summary_path = Path(path)
    if summary_path.exists():
        with summary_path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    return None


def load_log(path):
    log_path = Path(path)
    if log_path.exists():
        return pd.read_csv(log_path)
    return None


def main():
    st.set_page_config(page_title=DASHBOARD_TITLE, layout="wide")
    st.title(DASHBOARD_TITLE)

    agent = st.selectbox("Pilih Agent", ["Q-Learning", "DQN"])
    if agent == "DQN":
        summary, log_df = load_summary(DQN_SUMMARY_FILE), load_log(DQN_CSV_LOG_FILE)
    else:
        summary, log_df = load_summary(QL_SUMMARY_FILE), load_log(QL_CSV_LOG_FILE)

    if summary is None:
        st.warning(
            f"Belum ada ringkasan hasil {agent}. "
            "Jalankan `python rl_pentest\\main.py` (Q-Learning) atau "
            "`python rl_pentest\\train_dqn.py` (DQN) terlebih dahulu."
        )
        return

    st.header("Ringkasan Evaluasi")
    st.caption(summary.get("metrics_scope", "in-sample"))
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Request (payload)", summary.get("total_requests", 0))
    col2.metric("Total Vulnerability", summary.get("total_vulnerabilities", 0))
    col3.metric("Cumulative Reward", summary.get("cumulative_reward", 0))
    col4.metric("Vuln hit rate", summary.get("vuln_hit_rate", 0.0))

    st.subheader("Detail Tipe Serangan")
    st.write(
        {
            "SQL Injection": summary.get("sql_injection", 0),
            "Reflected XSS": summary.get("reflected_xss", 0),
            "Fuzzing Anomaly": summary.get("fuzzing_anomaly", 0),
        }
    )

    st.subheader("Transparansi Jumlah Request")
    st.write(
        {
            "Requests (payload)": summary.get("total_requests", 0),
            "Verification requests (benign \"hello\")": summary.get("verification_requests", 0),
            "Baseline probe requests": summary.get("baseline_probe_requests", 0),
            "Total requests keseluruhan": summary.get("total_requests_with_verification", summary.get("total_requests", 0)),
        }
    )

    if log_df is not None and not log_df.empty:
        st.subheader("Grafik Reward dan Response Time")
        st.line_chart(log_df[["reward", "response_time"]].cumsum())
        st.subheader("Payload dan Vulnerabilitas")
        st.dataframe(log_df[["timestamp", "action_name", "vulnerability", "status_code", "response_time"]].tail(20))
    else:
        st.info("Log CSV belum tersedia atau kosong. Pastikan training berhasil dieksekusi.")

    st.subheader("Ringkasan JSON")
    st.json(summary)


if __name__ == "__main__":
    main()