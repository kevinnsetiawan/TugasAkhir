import re
from typing import Dict
from config import RESPONSE_TIME_MEDIUM, RESPONSE_TIME_SLOW

SQL_ERROR_PATTERNS = [
    "syntax error", "sqlite", "mysql", "sqlstate", "sequelizeerror",
    "unclosed quotation", "odbc", "driver error",
]
SQL_PAYLOAD_SIGNATURES = [
    "' or", "or 1=1", "' or '", "union select", "select null",
    "and 1=1", "admin' --", "sleep(", "' and", "--",
]
# Injeksi wildcard: kolom pencarian memakai LIKE '%input%' sehingga '%' dan '_'
# yang diperbanyak membatalkan filter dan membocorkan seluruh baris.
SQL_WILDCARD_PATTERN = re.compile(r"%[%_sSdDxXnN]{4,}")
# Penanda pemotongan poison null byte (%2500) pada nama berkas, dan tipe konten
# yang sesuai untuk ekstensi yang diizinkan server (/ftp/ hanya mengizinkan
# .md dan .pdf). Bila keduanya tidak cocok, filter ekstensi berhasil dilewati.
POISON_NULL_BYTE = "%2500"
LFI_ALLOWED_CONTENT_TYPES = ("text/markdown", "text/plain", "application/pdf")
XSS_PAYLOAD_SIGNATURES = [
    "script", "onerror", "onload", "onclick", "onmouse",
    "javascript:", "alert(", "alert ", "svg/onload",
]
XSS_CONFIRMATION = [
    "<script>alert", "alert(1)", "alert('test')", 'alert("xss")',
    "onerror=alert", "onload=alert", "alert(document.domain)",
    "script>alert", "onload=alert", "svg/onload",
]
LFI_PAYLOAD_SIGNATURES = ["../", "..\\", "/etc/", "passwd", "boot.ini", "windows\\"]
# Bukti kebocoran berkas: isi berkas yang benar-benar dibaca server, bukan
# sekadar listing direktori publik (/ftp/ memang menyajikan .md secara normal).
LFI_CONFIRMATION = [
    "root:", "bin:", "/etc/passwd", "uid=", "windows system32",
    "\"name\": \"juice-shop\"", "\"version\":", "\"dependencies\":",
    "kdbx", "this document is confidential",
]
HTML_TAG_PATTERN = re.compile(r"<[a-z]+[^>]*>")
ERROR_PATTERNS = [
    "error", "exception", "warning", "fatal", "trace",
    "not found", "cannot", "unexpected",
]
CSP_HEADERS = {"content-security-policy"}
# Vektor XSS hanya berbahaya bila respons benar-benar disajikan sebagai HTML.
# Refleksi di dalam JSON tidak pernah dieksekusi browser.
HTML_CONTENT_TYPES = ("text/html", "application/xhtml")


class ResponseAnalyzer:
    def __init__(self, baseline_length: int = 2200, variance_threshold: float = 0.15):
        self.baseline_length = baseline_length
        self.variance_threshold = variance_threshold
        self.endpoint_baselines = {}

    @staticmethod
    def categorize_length(response_length: int) -> int:
        bins = (1500, 2500, 3500)
        for i, threshold in enumerate(bins):
            if response_length < threshold:
                return i
        return len(bins)

    @staticmethod
    def categorize_response_time(response_time: float) -> int:
        if response_time >= RESPONSE_TIME_SLOW:
            return 2
        if response_time >= RESPONSE_TIME_MEDIUM:
            return 1
        return 0

    @staticmethod
    def categorize_content_type(response) -> int:
        ct = (response.headers.get("Content-Type", "") if response else "").lower()
        if "json" in ct:
            return 0
        if "html" in ct:
            return 1
        if "text" in ct:
            return 2
        if "xml" in ct:
            return 3
        return 4

    def set_baselines(self, baselines: dict):
        self.endpoint_baselines.update(baselines)

    @staticmethod
    def served_as_html(response) -> bool:
        content_type = (response.headers.get("Content-Type", "") if response else "").lower()
        return any(marker in content_type for marker in HTML_CONTENT_TYPES)

    def _baseline_for(self, endpoint_index: int) -> int:
        return self.endpoint_baselines.get(endpoint_index, self.baseline_length)

    def analyze(self, response, payload: str, response_time: float = 0.0, endpoint_index: int = 0,
                surface: str = "sql") -> Dict[str, object]:
        if response is None:
            return {
                "status_code": 0,
                "status_category": "error",
                "response_length": 0,
                "length_category": 0,
                "error_flag": False,
                "reflected_flag": False,
                "significant_change": False,
                "vulnerability": "none",
                "request_error": True,
                "response_time_category": 0,
                "content_type_category": 0,
                "has_csp": False,
            }

        text = response.text
        text_lower = text.lower()
        status_code = response.status_code
        status_category = f"{status_code // 100}xx"
        response_length = len(text_lower)

        payload_lower = payload.lower() if payload else ""
        payload_reflected = bool(payload) and payload_lower in text_lower
        payload_reflected_partial = self._detect_partial_reflection(text_lower, payload_lower)

        error_flag = any(kw in text_lower for kw in SQL_ERROR_PATTERNS)
        is_sql_payload = any(sig in payload_lower for sig in SQL_PAYLOAD_SIGNATURES)
        is_xss_payload = any(sig in payload_lower for sig in XSS_PAYLOAD_SIGNATURES)
        reflected_flag = payload_reflected or payload_reflected_partial
        baseline = self._baseline_for(endpoint_index)
        significant_change = self._detect_significant_change(response_length, baseline)

        vulnerability = self._detect_vulnerability(
            text_lower, payload_lower, reflected_flag, error_flag,
            is_sql_payload, is_xss_payload, significant_change,
            status_code, response_length, baseline, surface,
            served_as_html=self.served_as_html(response),
            content_type=response.headers.get("Content-Type", "") if response else "",
        )

        has_csp = CSP_HEADERS.issubset(
            {k.lower() for k in (response.headers.keys() if response else [])}
        )

        return {
            "status_code": status_code,
            "status_category": status_category,
            "response_length": response_length,
            "length_category": self.categorize_length(response_length),
            "response_time_category": self.categorize_response_time(response_time),
            "content_type_category": self.categorize_content_type(response),
            "error_flag": error_flag,
            "reflected_flag": reflected_flag,
            "significant_change": significant_change,
            "vulnerability": vulnerability,
            "has_csp": has_csp,
            "request_error": False,
        }

    @staticmethod
    def _detect_partial_reflection(text: str, payload: str) -> bool:
        if not payload:
            return False
        tokens = re.findall(r"[\w'-]+", payload)
        long_tokens = [t for t in tokens if len(t) >= 4]
        if not long_tokens:
            return False
        return sum(1 for t in long_tokens if t in text) >= len(long_tokens) * 0.5

    def _detect_significant_change(self, response_length: int, baseline: int = None) -> bool:
        if baseline is None:
            baseline = self.baseline_length
        if baseline <= 0:
            return False
        ratio = abs(response_length - baseline) / baseline
        return ratio >= self.variance_threshold

    def _detect_vulnerability(
        self, text: str, payload: str, reflected: bool, error: bool,
        is_sql: bool, is_xss: bool, significant: bool,
        status_code: int, length: int, baseline: int, surface: str = "sql",
        served_as_html: bool = False, content_type: str = "",
    ) -> str:
        is_lfi = any(kw in payload.lower() for kw in LFI_PAYLOAD_SIGNATURES)
        is_fuzz = any(kw in payload for kw in ["%s", "%d", "%x", "%00", "\\x00"])
        has_disclosure = any(kw in text for kw in LFI_CONFIRMATION)
        has_xss_exec = any(kw in text for kw in XSS_CONFIRMATION)

        # --- SQLi (hanya pada permukaan ber-SQL) ---
        # Aturan ini TIDAK boleh dipakai di endpoint lain: /api/Challenges juga
        # mengembalikan seluruh koleksi saat diberi wildcard, tetapi backend-nya
        # NoSQL sehingga itu bukan SQL Injection. Klasifikasi mengikuti
        # permukaan yang dideklarasikan di config, bukan bentuk respons.
        if surface == "sql":
            # 1) Wildcard LIKE membatalkan filter dan membocorkan seluruh baris.
            if SQL_WILDCARD_PATTERN.search(payload) and significant and status_code < 400:
                return "sqli"
            # 2) Error database dipicu sintaks injeksi (bukan halaman error generik).
            if error and is_sql and status_code >= 400:
                return "sqli"
            # 3) Injeksi boolean/tautologi atau bypass autentikasi: pemuatan
            #    data tak wajar pada 2xx, dikonfirmasi lewat verifikasi
            #    kontrol-diferensial (mutant tanpa kutip).
            if is_sql and significant and status_code < 400:
                return "sqli"

        # --- XSS: hanya menjadi kandidat bila vektor muncul pada halaman HTML
        #     dan responsnya memang disajikan sebagai HTML. Refleksi di JSON
        #     (mis. /rest/track-order) tidak dieksekusi browser, jadi bukan
        #     bukti. Konfirmasi akhir dilakukan BrowserVerifier. ---
        if is_xss and served_as_html and status_code < 500 and (reflected or has_xss_exec):
            return "xss"

        # --- Path traversal / file disclosure (hanya pada permukaan berkas) ---
        if surface == "file":
            # 1) Konten berkas yang nyata (mis. /etc/passwd) muncul di respons.
            if is_lfi and has_disclosure:
                return "fuzzing"
            # 2) Bypass penyaring ekstensi: pemotongan poison null byte membuat
            #    server menyajikan berkas yang ekstensi aslinya terlarang, sehingga
            #    tipe konten yang disajikan TIDAK sesuai ekstensi yang diminta.
            #    Berkas .md/.pdf yang memang publik tidak memicu aturan ini.
            if self._extension_filter_bypassed(payload, status_code, content_type):
                return "fuzzing"

        # --- Fuzzing: hanya ketika error 5xx meng-echo payload probe mentah ---
        if status_code >= 500 and is_fuzz and payload in text:
            return "fuzzing"

        return "none"

    @staticmethod
    def _extension_filter_bypassed(payload: str, status_code: int, content_type: str) -> bool:
        if POISON_NULL_BYTE not in payload or status_code >= 400:
            return False
        content_type = (content_type or "").lower()
        return not any(marker in content_type for marker in LFI_ALLOWED_CONTENT_TYPES)
