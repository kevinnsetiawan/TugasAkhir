import json
import random
from pathlib import Path
from typing import Dict, List

class QLearningAgent:
    def __init__(
        self,
        n_actions: int,
        alpha: float = 0.1,
        gamma: float = 0.9,
        epsilon: float = 1.0,
        min_epsilon: float = 0.1,
        decay: float = 0.90,
        qtable_file: str = None,
        optimistic_init: float = 5.0,
    ):
        self.n_actions = n_actions
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.min_epsilon = min_epsilon
        self.decay = decay
        self.optimistic_init = optimistic_init
        self.qtable_file = Path(qtable_file) if qtable_file else None
        self.qtable: Dict[str, List[float]] = {}

        if self.qtable_file and self.qtable_file.exists():
            self.load_qtable()

    def _state_key(self, state) -> str:
        if isinstance(state, (tuple, list)):
            return "|".join(str(value) for value in state)
        return str(state)

    def _ensure_state(self, state_key: str):
        if state_key not in self.qtable:
            self.qtable[state_key] = [self.optimistic_init for _ in range(self.n_actions)]

    def choose_action(self, state, mask=None):
        state_key = self._state_key(state)
        self._ensure_state(state_key)

        allowed = [i for i in range(self.n_actions) if not mask or i not in mask]
        if not allowed:
            allowed = list(range(self.n_actions))

        if random.random() < self.epsilon:
            return random.choice(allowed)

        action_values = self.qtable[state_key]
        best_action = max(allowed, key=lambda index: action_values[index])
        return best_action

    def learn(self, state, action: int, reward: float, next_state):
        state_key = self._state_key(state)
        next_state_key = self._state_key(next_state)
        self._ensure_state(state_key)
        self._ensure_state(next_state_key)

        current_value = self.qtable[state_key][action]
        future_value = max(self.qtable[next_state_key])
        updated_value = current_value + self.alpha * (reward + self.gamma * future_value - current_value)
        self.qtable[state_key][action] = updated_value

    def decay_exploration(self):
        self.epsilon = max(self.min_epsilon, self.epsilon * self.decay)

    def save_qtable(self):
        if not self.qtable_file:
            return
        self.qtable_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.qtable_file, "w", encoding="utf-8") as handle:
            json.dump(self.qtable, handle, indent=2)

    def load_qtable(self):
        with open(self.qtable_file, "r", encoding="utf-8") as handle:
            self.qtable = json.load(handle)

    def get_best_action_values(self, state):
        state_key = self._state_key(state)
        self._ensure_state(state_key)
        return self.qtable[state_key]
