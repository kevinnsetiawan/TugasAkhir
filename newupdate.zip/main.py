import random
import shutil
import time

import numpy as np

import cyber_output as cyber
from analyzer.response_analyzer import ResponseAnalyzer
from agent.q_learning_agent import QLearningAgent
from baseline.zap_baseline import ZapBaseline
from config import (
    ALPHA,
    BASE_URL,
    ENDPOINTS,
    EPSILON_DECAY,
    EPSILON_MIN,
    EPSILON_START,
    GAMMA,
    OPTIMISTIC_INIT,
    PAYLOADS_FILE,
    QL_CSV_LOG_FILE,
    QL_SUMMARY_FILE,
    QTABLE_DIR,
    QTABLE_FILE,
    RESULTS_DIR,
    REQUEST_TIMEOUT,
    TOTAL_EPISODES,
    XSS_PAGES,
)
from analyzer.browser_verifier import BrowserVerifier
from engine.http_client import HTTPClient
from engine.payload_generator import PayloadGenerator
from evaluation.metrics import compute_metrics
from logger.result_logger import ResultLogger
from reward.reward_system import RewardSystem
from training_loop import probe_endpoint_baselines, run_episode


def ensure_directories():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    QTABLE_DIR.mkdir(parents=True, exist_ok=True)


def archive_previous_qtable():
    """Pindahkan Q-Table hasil run sebelumnya ke folder archive agar pelatihan
    selalu dimulai dari kondisi bersih (reproducible, tidak akumulatif antar run)."""
    if not QTABLE_FILE.exists():
        return None
    archive_dir = QTABLE_DIR / "archive"
    archive_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    destination = archive_dir / f"q_table_{stamp}.json"
    shutil.move(QTABLE_FILE, destination)
    return destination


RANDOM_SEED = 42
VULN_LABEL = {"sqli": "SQL-INJECTION", "xss": "XSS", "fuzzing": "INPUT-FUZZING"}


def run_training():
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)

    ensure_directories()
    archived = archive_previous_qtable()
    if archived:
        cyber.info(f"previous Q-Table archived -> {archived}")
    cyber.info("starting fresh run (empty Q-Table, seed 42)")

    n_endpoints = len(ENDPOINTS)
    payload_generator = PayloadGenerator(PAYLOADS_FILE, n_endpoints=n_endpoints)
    client = HTTPClient(BASE_URL, endpoints=ENDPOINTS, timeout=REQUEST_TIMEOUT)
    analyzer = ResponseAnalyzer()
    browser_verifier = BrowserVerifier(BASE_URL)
    reward_system = RewardSystem()
    agent = QLearningAgent(
        n_actions=payload_generator.get_action_count(),
        alpha=ALPHA,
        gamma=GAMMA,
        epsilon=EPSILON_START,
        min_epsilon=EPSILON_MIN,
        decay=EPSILON_DECAY,
        qtable_file=QTABLE_FILE,
        optimistic_init=OPTIMISTIC_INIT,
    )
    logger = ResultLogger(QL_CSV_LOG_FILE, QL_SUMMARY_FILE)

    baseline_probed = probe_endpoint_baselines(client, analyzer)
    current_state = ("2xx", 1, 0, 0, 0, 0, 0, 0)
    records = []
    total_reward = 0
    total_verification = 0
    discovered_actions = set()
    episodes_run = 0

    cyber.init()
    print("\n" + cyber.banner())
    cyber.info(f"TARGET       : {BASE_URL}")
    cyber.info(f"BUDGET       : {TOTAL_EPISODES} episodes (1 episode = 1 request payload)")
    cyber.info(f"ACTIONS      : {agent.n_actions} ({n_endpoints} endpoint x {agent.n_actions // n_endpoints} payload)")
    cyber.info(f"MAX_TRIES    : hanya aksi terverifikasi yang di-mask (tanpa anti-repetisi)")
    cyber.info(f"BASELINE     : {len(baseline_probed)} endpoint ter-probe")
    cyber.info(f"XSS SURFACE  : {len(XSS_PAGES)} halaman frontend diverifikasi via headless chromium")
    cyber.info(f"HYPERPARAMS  : alpha={ALPHA} gamma={GAMMA} eps={EPSILON_START}->{EPSILON_MIN} (decay {EPSILON_DECAY}) optimistic_init={OPTIMISTIC_INIT}")
    cyber.thinline()
    cyber.boot("probing endpoint baselines ...")
    cyber.boot("initializing Q-learning agent (exploration random rate seeded) ...")
    cyber.info("beginning reconnaissance sweep\n")

    training_start = time.monotonic()

    for episode in range(1, TOTAL_EPISODES + 1):
        mask = set(discovered_actions)
        record, next_state, reward, verification_requests = run_episode(
            agent, payload_generator, client, analyzer, reward_system, current_state, mask=mask,
            browser_verifier=browser_verifier, xss_pages=XSS_PAGES,
        )
        episodes_run = episode
        records.append(record)
        total_reward += reward
        total_verification += verification_requests
        current_state = next_state
        agent.decay_exploration()

        action = record["action_index"]
        if record["vulnerability"] != "none" and record["verified"]:
            discovered_actions.add(action)
            label = VULN_LABEL.get(record["vulnerability"], record["vulnerability"].upper())
            cyber.vuln(
                f"EP{episode:03d} :: {label} CONFIRMED @ {record['action_name']:<17} "
                f"reward {reward:+d} | eps {agent.epsilon:.4f} | known {len(discovered_actions)}/{agent.n_actions}"
            )

    cyber.ok(f"training completed across full budget of {TOTAL_EPISODES} episodes (no early-stop)")

    training_duration = round(time.monotonic() - training_start, 2)

    agent.save_qtable()
    logger.write_csv(records)
    summary = compute_metrics(records)
    summary["total_episodes"] = episodes_run
    summary["request_budget"] = TOTAL_EPISODES
    summary["discovered_actions"] = len(discovered_actions)
    summary["verified_actions"] = sorted(discovered_actions)
    summary["total_reward"] = total_reward
    summary["baseline_probe_requests"] = len(baseline_probed)
    summary["verification_requests"] = total_verification
    summary["total_requests_with_verification"] = episodes_run + len(baseline_probed) + total_verification
    summary["states_visited"] = len(agent.qtable)
    summary["training_duration_seconds"] = training_duration
    summary["browser_navigations"] = browser_verifier.navigations
    if not browser_verifier.available:
        summary["browser_verifier_warning"] = browser_verifier.unavailable_reason
    summary["qtable_file"] = str(QTABLE_FILE)
    summary["log_file"] = str(QL_CSV_LOG_FILE)
    summary["agent_type"] = "Q-Learning"
    logger.write_summary(summary)

    cyber.table_vuln_findings(records)
    cyber.table_per_endpoint(records, n_endpoints=len(ENDPOINTS))
    cyber.table_summary("Q-LEARNING", summary)
    cyber.info("writing artifacts: q_table.json / log_ql.csv / summary_ql.json")
    cyber.warn("angka di atas IN-SAMPLE; jalankan `python benchmark_detector.py` untuk precision/recall/F1 detektor")
    browser_verifier.close()

    if ZapBaseline(BASE_URL).is_available():
        cyber.boot("OWASP ZAP detected on localhost:8080 - launching baseline scan")
        zap = ZapBaseline(BASE_URL)
        zap_report = zap.scan_target()
        report_path = RESULTS_DIR / "zap_report.json"
        zap.save_report(report_path, data=zap_report)
        cyber.boot(f"ZAP report saved -> {report_path}")
    else:
        cyber.warn(
            "OWASP ZAP not available (install python-owasp-zap-v2.4 and run ZAP on :8080 to enable baseline scan)"
        )

    print("\n" + cyber.banner())
    cyber.ok("SESSION COMPLETE :: verify results/ for full log & summary")
    cyber.ok("Q-table converged - RL agent is ready for the next campaign\n")


if __name__ == "__main__":
    run_training()