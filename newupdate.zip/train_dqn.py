import random
import time

import numpy as np

import cyber_output as cyber
from agent.dqn_agent import DQNAgent
from analyzer.browser_verifier import BrowserVerifier
from analyzer.response_analyzer import ResponseAnalyzer
from config import (
    ALPHA,
    BASE_URL,
    DQN_BATCH_SIZE,
    DQN_CSV_LOG_FILE,
    DQN_EPSILON_DECAY,
    DQN_HIDDEN_DIM,
    DQN_LR,
    DQN_REPLAY_CAPACITY,
    DQN_SUMMARY_FILE,
    DQN_TARGET_UPDATE_INTERVAL,
    ENDPOINTS,
    EPSILON_MIN,
    EPSILON_START,
    GAMMA,
    PAYLOADS_FILE,
    QTABLE_DIR,
    REQUEST_TIMEOUT,
    TOTAL_EPISODES,
    XSS_PAGES,
)
from engine.http_client import HTTPClient
from engine.payload_generator import PayloadGenerator
from evaluation.metrics import compute_metrics
from logger.result_logger import ResultLogger
from reward.reward_system import RewardSystem
from training_loop import probe_endpoint_baselines, run_episode


def ensure_directories():
    DQN_CSV_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)


RANDOM_SEED = 42
VULN_LABEL = {"sqli": "SQL-INJECTION", "xss": "XSS", "fuzzing": "INPUT-FUZZING"}
PROGRESS_EVERY = 50


def run_training():
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)

    ensure_directories()
    n_endpoints = len(ENDPOINTS)
    payload_generator = PayloadGenerator(PAYLOADS_FILE, n_endpoints=n_endpoints)
    client = HTTPClient(BASE_URL, endpoints=ENDPOINTS, timeout=REQUEST_TIMEOUT)
    analyzer = ResponseAnalyzer()
    browser_verifier = BrowserVerifier(BASE_URL)
    reward_system = RewardSystem()
    agent = DQNAgent(
        n_actions=payload_generator.get_action_count(),
        epsilon=EPSILON_START,
        min_epsilon=EPSILON_MIN,
        decay=DQN_EPSILON_DECAY,
        gamma=GAMMA,
        alpha=DQN_LR,
        batch_size=DQN_BATCH_SIZE,
        hidden_dim=DQN_HIDDEN_DIM,
        replay_capacity=DQN_REPLAY_CAPACITY,
        target_update_interval=DQN_TARGET_UPDATE_INTERVAL,
    )
    logger = ResultLogger(DQN_CSV_LOG_FILE, DQN_SUMMARY_FILE)

    baseline_probed = probe_endpoint_baselines(client, analyzer)
    current_state = ("2xx", 1, 0, 0, 0, 0, 0, 0)
    records = []
    total_reward = 0
    total_verification = 0
    discovered_actions = set()
    episodes_run = 0

    cyber.init()
    print("\n" + cyber.banner("DQN"))
    cyber.info(f"TARGET       : {BASE_URL}")
    cyber.info(f"BUDGET       : {TOTAL_EPISODES} episodes (1 episode = 1 request payload)")
    cyber.info(f"ACTIONS      : {agent.n_actions} ({n_endpoints} endpoint x {agent.n_actions // n_endpoints} payload)")
    cyber.info(f"NETWORK      : MLP 28-{agent.policy_net.net[0].out_features}-{agent.policy_net.net[4].out_features} (state one-hot + target net)")
    cyber.info(f"DEVICE       : {agent.device}")
    cyber.info(f"REPLAY       : capacity {agent.replay_buffer.buffer.maxlen} | batch {agent.batch_size} | target sync tiap {agent.target_update_interval} step")
    cyber.info(f"MASKING      : hanya aksi terverifikasi yang di-mask (tanpa anti-repetisi)")
    cyber.info(f"BASELINE     : {len(baseline_probed)} endpoint ter-probe")
    cyber.info(f"XSS SURFACE  : {len(XSS_PAGES)} halaman frontend diverifikasi via headless chromium")
    cyber.info(f"HYPERPARAMS  : lr={DQN_LR} gamma={GAMMA} eps={EPSILON_START}->{EPSILON_MIN} (decay {DQN_EPSILON_DECAY})")
    cyber.thinline()
    cyber.boot("probing endpoint baselines ...")
    cyber.boot("initializing DQN agent (target net synced, exploration rate seeded) ...")
    cyber.info("beginning reconnaissance sweep\n")

    training_start = time.monotonic()

    for episode in range(1, TOTAL_EPISODES + 1):
        mask = set(discovered_actions)
        record, next_state, reward, verification_requests = run_episode(
            agent, payload_generator, client, analyzer, reward_system, current_state, mask=mask,
            browser_verifier=browser_verifier, xss_pages=XSS_PAGES,
        )
        episodes_run = episode
        records.append(record)
        total_reward += reward
        total_verification += verification_requests
        current_state = next_state
        agent.decay_exploration()

        action = record["action_index"]
        if record["vulnerability"] != "none" and record["verified"]:
            discovered_actions.add(action)
            label = VULN_LABEL.get(record["vulnerability"], record["vulnerability"].upper())
            cyber.vuln(
                f"EP{episode:03d} :: {label} CONFIRMED @ {record['action_name']:<17} "
                f"reward {reward:+d} | eps {agent.epsilon:.4f} | known {len(discovered_actions)}/{agent.n_actions}"
            )

        if episode % PROGRESS_EVERY == 0 or episode == TOTAL_EPISODES:
            elapsed = time.monotonic() - training_start
            rate = episode / elapsed if elapsed else 0.0
            cyber.log(
                "EP%04d/%d %s eps %.4f | found %2d/%d | rew %+d | %.1f ep/s | %ds"
                % (episode, TOTAL_EPISODES, cyber.progress_bar(episode, TOTAL_EPISODES),
                   agent.epsilon, len(discovered_actions), agent.n_actions,
                   total_reward, rate, elapsed),
                "=", cyber.CYAN,
            )

    cyber.ok(f"training completed across full budget of {TOTAL_EPISODES} episodes (no early-stop)")

    training_duration = round(time.monotonic() - training_start, 2)

    model_path = QTABLE_DIR / "dqn_model.pt"
    agent.save_model(str(model_path))
    logger.write_csv(records)
    summary = compute_metrics(records)
    summary["total_episodes"] = episodes_run
    summary["request_budget"] = TOTAL_EPISODES
    summary["discovered_actions"] = len(discovered_actions)
    summary["verified_actions"] = sorted(discovered_actions)
    summary["total_reward"] = total_reward
    summary["baseline_probe_requests"] = len(baseline_probed)
    summary["verification_requests"] = total_verification
    summary["total_requests_with_verification"] = episodes_run + len(baseline_probed) + total_verification
    summary["model_file"] = str(model_path)
    summary["log_file"] = str(DQN_CSV_LOG_FILE)
    summary["training_duration_seconds"] = training_duration
    summary["browser_navigations"] = browser_verifier.navigations
    if not browser_verifier.available:
        summary["browser_verifier_warning"] = browser_verifier.unavailable_reason
    summary["agent_type"] = "DQN"
    logger.write_summary(summary)

    cyber.table_vuln_findings(records)
    cyber.table_per_endpoint(records, n_endpoints=len(ENDPOINTS))
    cyber.table_summary("DQN", summary)
    cyber.info("writing artifacts: dqn_model.pt / log_dqn.csv / summary_dqn.json")
    cyber.warn("angka di atas IN-SAMPLE; jalankan `python benchmark_detector.py` untuk precision/recall/F1 detektor")
    browser_verifier.close()
    print("\n" + cyber.banner("DQN"))
    cyber.ok("SESSION COMPLETE :: verify results/ for full log & summary")
    cyber.ok("Deep Q-network converged - RL agent is ready for the next campaign\n")


if __name__ == "__main__":
    run_training()