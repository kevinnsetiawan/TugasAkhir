import json
import requests
from config import ZAP_API_KEY, ZAP_API_URL

try:
    from zapv2 import ZAPv2
except ImportError:  # pragma: no cover
    ZAPv2 = None

class ZapBaseline:
    def __init__(self, target_url: str):
        self.target_url = target_url
        self.api_url = ZAP_API_URL

    def is_available(self) -> bool:
        if ZAPv2 is None:
            return False
        try:
            response = requests.get(self.api_url, timeout=4)
            return response.status_code in {200, 401, 403}
        except requests.RequestException:
            return False

    def scan_target(self) -> dict:
        if ZAPv2 is None:
            return {
                "status": "missing",
                "message": (
                    "Modul python-owasp-zap-v2.4 tidak terpasang. "
                    "Jalankan `pip install python-owasp-zap-v2.4` jika ingin menggunakan baseline ZAP."
                ),
            }

        if not self.is_available():
            return {
                "status": "unavailable",
                "message": "Server ZAP tidak tersedia di {}".format(self.api_url),
            }

        zap = ZAPv2(apikey=ZAP_API_KEY, proxies={"http": self.api_url, "https": self.api_url})
        try:
            scan_id = zap.ascan.scan(self.target_url)
            for _ in range(100):
                if int(zap.ascan.status(scan_id)) >= 100:
                    break
            alerts = zap.core.alerts(baseurl=self.target_url)
            return {"status": "completed", "alerts": alerts}
        except Exception as exc:
            return {"status": "error", "message": str(exc)}

    def save_report(self, path: str, data: dict = None):
        if data is None:
            data = self.scan_target()
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2)
